/* On Course Manager: hand the summary to the page, and ask for a fresh sync when the page wants one */
document.documentElement.dataset.cmIlearnHelper = chrome.runtime.getManifest().version;
const cmSend = () => chrome.storage.local.get("cm").then(({ cm }) => { if (cm) window.postMessage({ cmIlearn: cm }, location.origin); });
window.addEventListener("message", e => {
  if (e.source !== window || !e.data || !e.data.cmIlearnPing) return;
  cmSend(); chrome.runtime.sendMessage({ type: "sync", source: "site" }).catch(() => {});
});
chrome.storage.onChanged.addListener(c => { if (c.cm) cmSend(); });
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", cmSend); else cmSend();
