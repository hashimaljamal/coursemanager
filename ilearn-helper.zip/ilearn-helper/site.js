/* On Course Manager: hand the summary to the page, and ask for a fresh sync when the page wants one */
document.documentElement.dataset.cmIlearnHelper = chrome.runtime.getManifest().version;
const cmSend = () => chrome.storage.local.get("cm").then(({ cm }) => { if (cm) window.postMessage({ cmIlearn: cm }, location.origin); });
window.addEventListener("message", e => {
  if (e.source !== window || !e.data) return;
  /* reminder settings: the key the relay knows your devices by, and which iLearn alerts you want */
  if (e.data.cmNotif) { const n = e.data.cmNotif; chrome.storage.local.set({ cmNotif: n.off ? null : { key: String(n.key || ""), relay: String(n.relay || ""), on: n.on || {} } }); return; }
  if (!e.data.cmIlearnPing) return;
  cmSend(); chrome.runtime.sendMessage({ type: "sync", source: "site" }).catch(() => {});
});
chrome.storage.onChanged.addListener(c => { if (c.cm) cmSend(); });
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", cmSend); else cmSend();
