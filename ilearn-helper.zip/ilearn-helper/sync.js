/* Reads your iLearn courses and calendar with your own iLearn login (read-only) and keeps a small summary:
   which course each dated item belongs to. Used by the background worker and by the iLearn tab itself. */
var CM_BB = "https://ilearn.aus.edu";
async function cmApi(path) {
  const r = await fetch(CM_BB + path, { credentials: "include", headers: { Accept: "application/json" } });
  if (r.status === 401 || r.status === 403) { const e = new Error("login"); e.login = true; throw e; }
  if (!r.ok) throw new Error("HTTP " + r.status + " for " + path.split("?")[0]);
  const t = await r.text();
  if (/^\s*</.test(t)) { const e = new Error("login"); e.login = true; throw e; } /* got the login page */
  return JSON.parse(t);
}
async function cmAll(path) {
  const out = []; let next = path, guard = 0;
  while (next && guard++ < 30) {
    const j = await cmApi(next); out.push(...(j.results || []));
    next = j.paging && j.paging.nextPage ? j.paging.nextPage.replace(/^https?:\/\/[^/]+/, "") : null;
  }
  return out;
}
const cmIso = d => d.toISOString();
/* full: courses, terms, calendar and every course's gradebook (about a dozen requests).
   quick: just the calendar (2–3 requests), reusing the course list from the last full check */
async function cmSync(prev, full) {
  if (!full && prev && prev.courses && prev.courses.length && prev.items) return cmQuick(prev);
  const me = await cmApi("/learn/api/public/v1/users/me?fields=id,userName");
  /* your courses */
  let mem = [];
  try { mem = await cmAll(`/learn/api/public/v1/users/${me.id}/courses?expand=course&limit=200&fields=courseId,course.id,course.courseId,course.name,course.termId,course.externalAccessUrl`); } catch (e) { }
  const courses = {};
  for (const m of mem) { const c = m.course || {}; const id = c.id || m.courseId; if (!id) continue; courses[id] = { id, courseId: c.courseId || "", name: c.name || "", termId: c.termId || "", url: c.externalAccessUrl || "" }; }
  if (mem.length && !mem.some(m => m.course)) {
    for (const id of Object.keys(courses)) { try { const c = await cmApi(`/learn/api/public/v1/courses/${id}?fields=id,courseId,name,termId`); courses[id] = { id, courseId: c.courseId || "", name: c.name || "", termId: c.termId || "" }; } catch (e) { } }
  }
  const terms = {};
  for (const t of new Set(Object.values(courses).map(c => c.termId).filter(Boolean))) { try { const j = await cmApi(`/learn/api/public/v1/terms/${t}?fields=id,name`); terms[t] = j.name || ""; } catch (e) { } }
  for (const c of Object.values(courses)) c.term = terms[c.termId] || "";
  /* dated items: the calendar, in windows of 14 weeks (the API limits the range) */
  const items = {}, now = Date.now(), DAY = 864e5;
  const put = (num, cal, title, due, src, kind) => { if (!num || !cal || kind === "OfficeHours") return; if (!items[num] || src === "cal") items[num] = { c: cal, t: title || "", d: due || "", ...(kind ? { k: kind } : {}) }; };
  const numOf = s => { const m = String(s || "").match(/_(\d+)_1\b/g); return m ? m[m.length - 1].match(/\d+/)[0] : ""; };
  let calOk = false, calErr = null;
  for (let a = now - 140 * DAY; a < now + 200 * DAY; a += 98 * DAY) {
    const b = Math.min(a + 98 * DAY, now + 200 * DAY);
    try {
      const res = await cmAll(`/learn/api/public/v1/calendars/items?since=${encodeURIComponent(cmIso(new Date(a)))}&until=${encodeURIComponent(cmIso(new Date(b)))}&limit=200`);
      calOk = true;
      for (const it of res) {
        if (!courses[it.calendarId] && it.type !== "Course" && it.type !== "GradebookColumn") continue;
        put(numOf(it.id), it.calendarId, it.title, it.end || it.start, "cal", it.type);
        if (!courses[it.calendarId] && it.calendarId) courses[it.calendarId] = { id: it.calendarId, courseId: "", name: it.calendarName || "", term: "" };
        else if (courses[it.calendarId] && !courses[it.calendarId].name && it.calendarName) courses[it.calendarId].name = it.calendarName;
      }
    } catch (e) { calErr = e; }
  }
  if (!calOk && calErr) throw calErr; /* the calendar is the one thing that has to work */
  /* due dates straight from each course's gradebook: these ids are the ones in the calendar link */
  /* only this term's courses (AUS names them like CMP305_10208_F26), so a full check stays a handful of requests */
  const d0 = new Date(), mo = d0.getMonth(), yy = String(d0.getFullYear()).slice(2), tok = mo <= 4 ? "S" : mo <= 6 ? "(?:U|SU)" : "F";
  const termRe = new RegExp("(^|[^A-Za-z0-9])" + tok + yy + "([^0-9]|$)");
  for (const id of Object.keys(courses).filter(id => termRe.test(courses[id].courseId + " " + courses[id].name)).slice(0, 25)) {
    try {
      const cols = await cmAll(`/learn/api/public/v2/courses/${id}/gradebook/columns?limit=200&fields=id,name,grading.due`);
      for (const col of cols) if (col.grading && col.grading.due) put(numOf(col.id), id, col.name, col.grading.due, "gb");
    } catch (e) { /* students often can't read the gradebook: fine, the calendar has the dates */ }
  }
  /* this term's courses only: what you've submitted, your grades, and announcements */
  const grades = {}, news = {};
  const text = h => String(h || "").replace(/<(br|\/p|\/div|\/li)[^>]*>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();
  for (const id of Object.keys(courses).filter(id => termRe.test(courses[id].courseId + " " + courses[id].name)).slice(0, 25)) {
    let names = {};
    try { for (const col of await cmAll(`/learn/api/public/v2/courses/${id}/gradebook/columns?limit=200&fields=id,name,score.possible,grading.due,includeInCalculations`)) names[col.id] = { t: col.name || "", p: col.score && col.score.possible, d: col.grading && col.grading.due || "" }; } catch (e) { }
    try {
      const gs = await cmAll(`/learn/api/public/v2/courses/${id}/gradebook/users/${me.id}?limit=200&fields=columnId,status,displayGrade,exempt,lastRelevantDate,feedback`);
      for (const g of gs) {
        const n = numOf(g.columnId); if (!n) continue;
        if (items[n] && g.status) items[n].s = g.status;
        const dg = g.displayGrade || {}, col = names[g.columnId] || {};
        if (dg.score != null && !g.exempt) grades[n] = { c: id, t: col.t || (items[n] && items[n].t) || "", sc: +dg.score, p: dg.possible != null ? +dg.possible : col.p != null ? +col.p : null, st: g.status || "", at: g.lastRelevantDate || "", d: col.d || "", ...(g.feedback ? { f: text(g.feedback).slice(0, 1500) } : {}) };
      }
    } catch (e) { }
    try {
      for (const a of await cmAll(`/learn/api/public/v1/courses/${id}/announcements?limit=100&fields=id,title,body,created,modified,draft`)) {
        if (a.draft) continue;
        news[a.id] = { c: id, t: a.title || "", b: text(a.body).slice(0, 4000), d: a.created || "", m: a.modified || "" };
      }
    } catch (e) { }
  }
  return { v: 2, at: Date.now(), full: Date.now(), user: me.userName || "", calOk, courses: Object.values(courses), items, grades, news };
}
async function cmQuick(prev) {
  const items = { ...prev.items }, courses = {}, now = Date.now(), DAY = 864e5;
  for (const c of prev.courses) courses[c.id] = c;
  const numOf = s => { const m = String(s || "").match(/_(\d+)_1\b/g); return m ? m[m.length - 1].match(/\d+/)[0] : ""; };
  for (let a = now - 14 * DAY; a < now + 180 * DAY; a += 98 * DAY) {
    const b = Math.min(a + 98 * DAY, now + 180 * DAY);
    const res = await cmAll(`/learn/api/public/v1/calendars/items?since=${encodeURIComponent(cmIso(new Date(a)))}&until=${encodeURIComponent(cmIso(new Date(b)))}&limit=200`);
    for (const it of res) {
      const n = numOf(it.id); if (!n || !it.calendarId || it.type === "OfficeHours") continue;
      if (!courses[it.calendarId]) courses[it.calendarId] = { id: it.calendarId, courseId: "", name: it.calendarName || "", term: "" };
      items[n] = { c: it.calendarId, t: it.title || "", d: it.end || it.start || "", k: it.type, ...(items[n] && items[n].s ? { s: items[n].s } : {}) };
    }
  }
  return { ...prev, v: 1, at: Date.now(), courses: Object.values(courses), items };
}
