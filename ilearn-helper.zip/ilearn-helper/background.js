importScripts("sync.js");
let running = null;
async function run(source) {
  if (running) return running;
  const { cm: prev } = await chrome.storage.local.get("cm");
  if ((source === "site" || source === "quick") && prev && prev.at && !prev.login && Date.now() - prev.at < 60000) return;
  const full = !prev || !prev.full || Date.now() - prev.full > 60 * 60000 || source === "popup" || source === "install" || source === "startup";
  running = (async () => {
    try {
      const data = await cmSync(prev, full);
      await chrome.storage.local.set({ cm: { ...data, login: false, source } });
      chrome.action.setBadgeText({ text: "" });
      chrome.action.setTitle({ title: `Course Manager · iLearn helper\nChecked ${new Date().toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})}: ${Object.keys(data.items).length} items in ${data.courses.length} courses` });
    } catch (e) {
      const { cm } = await chrome.storage.local.get("cm");
      if (e && e.login) {
        await chrome.storage.local.set({ cm: { ...(cm || {}), login: true, checked: Date.now() } });
        chrome.action.setBadgeBackgroundColor({ color: "#d0021b" }); chrome.action.setBadgeText({ text: "!" });
        chrome.action.setTitle({ title: "Course Manager · iLearn helper\nLog in to iLearn so new due dates can be sorted." });
      } else {
        await chrome.storage.local.set({ cm: { ...(cm || {}), error: String(e && e.message || e), checked: Date.now() } });
      }
    } finally { running = null; }
  })();
  return running;
}
/* a quick check every 2 minutes (just the calendar), a full one every hour */
const cmAlarm = () => chrome.alarms.create("sync", { periodInMinutes: 2 });
chrome.runtime.onInstalled.addListener(() => { cmAlarm(); run("install"); });
chrome.runtime.onStartup.addListener(() => { cmAlarm(); run("startup"); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === "sync") run("quick"); });
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "sync") { run(msg.source || "site").then(() => reply({ ok: true })); return true; }
  /* the iLearn tab synced by itself (its requests always carry your login) */
  if (msg && msg.type === "save" && msg.data) {
    chrome.storage.local.set({ cm: { ...msg.data, login: false, source: "ilearn-tab" } }).then(() => { chrome.action.setBadgeText({ text: "" }); reply({ ok: true }); });
    return true;
  }
});
