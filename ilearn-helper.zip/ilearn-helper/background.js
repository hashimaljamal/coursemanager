importScripts("sync.js");
let running = null;
async function run(source) {
  if (running) return running;
  if (source === "site") { const { cm } = await chrome.storage.local.get("cm"); if (cm && cm.at && !cm.login && Date.now() - cm.at < 10 * 60000) return; }
  running = (async () => {
    try {
      const data = await cmSync();
      await chrome.storage.local.set({ cm: { ...data, login: false, source } });
      chrome.action.setBadgeText({ text: "" });
      chrome.action.setTitle({ title: `Course Manager · iLearn helper\nUp to date: ${Object.keys(data.items).length} items in ${data.courses.length} courses` });
    } catch (e) {
      const { cm } = await chrome.storage.local.get("cm");
      if (e && e.login) {
        await chrome.storage.local.set({ cm: { ...(cm || {}), login: true, checked: Date.now() } });
        chrome.action.setBadgeBackgroundColor({ color: "#d0021b" }); chrome.action.setBadgeText({ text: "!" });
        chrome.action.setTitle({ title: "Course Manager · iLearn helper\nLog in to iLearn so new due dates can be sorted." });
      } else {
        await chrome.storage.local.set({ cm: { ...(cm || {}), error: String(e && e.message || e), checked: Date.now() } });
      }
    } finally { running = null; }
  })();
  return running;
}
chrome.runtime.onInstalled.addListener(() => { chrome.alarms.create("sync", { periodInMinutes: 60 }); run("install"); });
chrome.runtime.onStartup.addListener(() => { chrome.alarms.create("sync", { periodInMinutes: 60 }); run("startup"); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === "sync") run("hourly"); });
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "sync") { run(msg.source || "site").then(() => reply({ ok: true })); return true; }
  /* the iLearn tab synced by itself (its requests always carry your login) */
  if (msg && msg.type === "save" && msg.data) {
    chrome.storage.local.set({ cm: { ...msg.data, login: false, source: "ilearn-tab" } }).then(() => { chrome.action.setBadgeText({ text: "" }); reply({ ok: true }); });
    return true;
  }
});
