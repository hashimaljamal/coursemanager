importScripts("sync.js");
let running = null;
async function run(source) {
  if (running) return running;
  const { cm: prev } = await chrome.storage.local.get("cm");
  if ((source === "site" || source === "quick") && prev && prev.at && !prev.login && Date.now() - prev.at < 60000) return;
  const full = !prev || !prev.full || Date.now() - prev.full > 30 * 60000 || source === "popup" || source === "install" || source === "startup";
  running = (async () => {
    try {
      const data = await cmSync(prev, full);
      await chrome.storage.local.set({ cm: { ...data, login: false, source } });
      await cmAlert(prev, data);
      chrome.action.setBadgeText({ text: "" });
      chrome.action.setTitle({ title: `Course Manager · iLearn helper\nChecked ${new Date().toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})}: ${Object.keys(data.items).length} items in ${data.courses.length} courses` });
    } catch (e) {
      const { cm } = await chrome.storage.local.get("cm");
      if (e && e.login) {
        await chrome.storage.local.set({ cm: { ...(cm || {}), login: true, checked: Date.now() } });
        chrome.action.setBadgeBackgroundColor({ color: "#d0021b" }); chrome.action.setBadgeText({ text: "!" });
        chrome.action.setTitle({ title: "Course Manager · iLearn helper\nLog in to iLearn so new due dates can be sorted." });
      } else {
        await chrome.storage.local.set({ cm: { ...(cm || {}), error: String(e && e.message || e), checked: Date.now() } });
      }
    } finally { running = null; }
  })();
  return running;
}
/* a quick check every 2 minutes (just the calendar), a full one (grades, announcements) every 30 minutes */
const cmAlarm = () => chrome.alarms.create("sync", { periodInMinutes: 2 });
chrome.runtime.onInstalled.addListener(() => { cmAlarm(); run("install"); });
chrome.runtime.onStartup.addListener(() => { cmAlarm(); run("startup"); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === "sync") run("quick"); });
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "sync") { run(msg.source || "site").then(() => reply({ ok: true })); return true; }
  /* the iLearn tab synced by itself (its requests always carry your login) */
  if (msg && msg.type === "save" && msg.data) {
    chrome.storage.local.get("cm").then(({ cm }) => cmAlert(cm, msg.data)).catch(() => {});
    chrome.storage.local.set({ cm: { ...msg.data, login: false, source: "ilearn-tab" } }).then(() => { chrome.action.setBadgeText({ text: "" }); reply({ ok: true }); });
    return true;
  }
});

/* reminders: tell your devices about new grades, announcements and due date changes (only what changed since the last check) */
let alerting = Promise.resolve();
function cmAlert(prev, data) { alerting = alerting.then(() => cmAlert0(prev, data)).catch(() => {}); return alerting; }
async function cmAlert0(prev, data) {
  const { cmNotif: n } = await chrome.storage.local.get("cmNotif");
  if (!n || !/^[a-f0-9]{32}$/.test(n.key || "") || !/^https:\/\//.test(n.relay || "") || !prev || !prev.at || !data) return;
  const on = n.on || {}, out = [], now = Date.now();
  const course = id => { const c = (data.courses || []).find(x => x.id === id) || {}; const m = String(c.courseId || "").match(/^([A-Z]{2,4})\s?(\d{3}[A-Z]?)/);
    return m ? m[1] + " " + m[2] : String(c.name || "iLearn").replace(/\s*\([^)]*\)\s*$/, "").slice(0, 40); };
  const when = s => { const d = new Date(s); return isNaN(d) ? "" : d.toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }); };
  /* grades and announcements only change on a full check, and only compare against one */
  if (on.ilgrade && prev.grades && data.grades && data.grades !== prev.grades)
    for (const k in data.grades) { const g = data.grades[k], p = prev.grades[k]; if (p && p.sc === g.sc && p.p === g.p) continue;
      out.push({ title: `New grade · ${course(g.c)}`, body: `${g.t || "Grade"}: ${g.sc}${g.p != null ? " / " + g.p : ""}`, url: "./#courses", tag: "ilg:" + k }); }
  if (on.ilnews && prev.news && data.news && data.news !== prev.news)
    for (const k in data.news) { if (prev.news[k]) continue; const a = data.news[k];
      out.push({ title: `Announcement · ${course(a.c)}`, body: a.t || String(a.b || "").slice(0, 140), url: "./#home", tag: "iln:" + k }); }
  if (on.ilmoved && prev.items && data.items)
    for (const k in data.items) { const x = data.items[k], p = prev.items[k], t = +new Date(x.d);
      if (!x.d || !(t > now) || t > now + 120 * 864e5 || (p && p.d === x.d)) continue;
      out.push({ title: `${p ? "Due date moved" : "New due date"} · ${course(x.c)}`, body: `${x.t || "Item"}: ${when(x.d)}`, url: "./#tasks", tag: "ilm:" + k }); }
  if (!out.length) return;
  const send = it => fetch(n.relay.replace(/\/$/, "") + "?push=now", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key: n.key, ...it }) }).catch(() => {});
  /* a big batch (say, a new course's whole calendar) becomes one summary */
  if (out.length > 5) { for (const it of out.slice(0, 3)) await send(it); await send({ title: "More from iLearn", body: `${out.length - 3} more updates: grades, announcements or due dates`, url: "./#home", tag: "il-more" }); }
  else for (const it of out) await send(it);
}
