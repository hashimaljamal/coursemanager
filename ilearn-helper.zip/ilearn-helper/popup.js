const ago = t => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? "just now" : m < 60 ? m + " min ago" : m < 1440 ? Math.round(m / 60) + " h ago" : new Date(t).toLocaleDateString(); };
async function show() {
  const { cm } = await chrome.storage.local.get("cm"), s = document.getElementById("s");
  if (!cm) { s.innerHTML = "<p>Not checked yet.</p>"; return; }
  s.innerHTML = (cm.login ? `<p class="bad"><b class="bad">Log in to iLearn</b> so new due dates can be sorted. <a href="https://ilearn.aus.edu" target="_blank">Open iLearn</a></p>` : "")
    + (cm.at ? `<p><b>${Object.keys(cm.items || {}).length} items</b> in <b>${(cm.courses || []).length} courses</b>, checked ${ago(cm.at)}.</p>` : "")
    + (cm.error ? `<p class="bad">Last check failed: ${cm.error}</p>` : "")
    + `<p>Open Course Manager and your iLearn due dates are sorted into courses automatically.</p>`;
}
document.getElementById("go").onclick = async () => { document.getElementById("s").innerHTML = "<p>Checking…</p>"; await chrome.runtime.sendMessage({ type: "sync", source: "popup" }); show(); };
show();
