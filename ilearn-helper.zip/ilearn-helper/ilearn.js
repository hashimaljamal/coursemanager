/* On iLearn pages: sync from here too, at most every 10 minutes, so a fresh login fixes things right away */
(async () => {
  try {
    const { cm } = await chrome.storage.local.get("cm");
    if (cm && !cm.login && cm.at && Date.now() - cm.at < 2 * 60000) return;
    const data = await cmSync(cm && !cm.login ? cm : null, !cm || !cm.full || Date.now() - cm.full > 60 * 60000);
    chrome.runtime.sendMessage({ type: "save", data });
  } catch (e) { /* not logged in yet, or iLearn busy: try again on the next page */ }
})();
